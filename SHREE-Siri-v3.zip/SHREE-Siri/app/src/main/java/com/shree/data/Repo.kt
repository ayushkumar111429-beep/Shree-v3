package com.shree.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "msgs")
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,          // "user" | "assistant"
    val text: String,
    val ts: Long = System.currentTimeMillis()
)

@Dao
interface MsgDao {
    @Insert suspend fun insert(m: Msg): Long
    @Query("SELECT * FROM msgs ORDER BY ts ASC") fun all(): Flow<List<Msg>>
    @Query("SELECT * FROM msgs ORDER BY ts DESC LIMIT :n") suspend fun recent(n: Int): List<Msg>
    @Query("DELETE FROM msgs WHERE ts < :cut") suspend fun prune(cut: Long)
    @Query("DELETE FROM msgs") suspend fun clear()
}

@Database(entities = [Msg::class], version = 1, exportSchema = false)
abstract class DB : RoomDatabase() {
    abstract fun dao(): MsgDao
    companion object {
        @Volatile private var I: DB? = null
        fun get(ctx: Context) = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(ctx.applicationContext, DB::class.java, "shree.db")
                .fallbackToDestructiveMigration().build().also { I = it }
        }
    }
}

class Repo(ctx: Context) {
    private val dao = DB.get(ctx).dao()
    val flow: Flow<List<Msg>> = dao.all()

    suspend fun add(role: String, text: String): Msg {
        val m = Msg(role = role, text = text)
        val id = dao.insert(m)
        return m.copy(id = id)
    }

    /** Return last N pairs formatted for the Anthropic API */
    suspend fun apiHistory(n: Int = 14): List<Pair<String, String>> =
        dao.recent(n).reversed().map { it.role to it.text }

    suspend fun prune() = dao.prune(System.currentTimeMillis() - 7 * 86_400_000L)
    suspend fun clear() = dao.clear()

    companion object {
        @Volatile private var I: Repo? = null
        fun get(ctx: Context) = I ?: synchronized(this) {
            I ?: Repo(ctx.applicationContext).also { I = it }
        }
    }
}
