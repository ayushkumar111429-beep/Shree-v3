package com.shree.commands

import android.app.AlarmClock
import android.app.admin.DevicePolicyManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.provider.AlarmClock.ACTION_SET_ALARM
import android.provider.AlarmClock.ACTION_SET_TIMER
import android.provider.AlarmClock.ACTION_SHOW_ALARMS
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import com.shree.service.AdminReceiver
import java.util.Calendar

sealed class ExecResult {
    data class Ok(val reply: String) : ExecResult()
    data class NeedPerm(val perm: String, val reply: String) : ExecResult()
    data class NeedAdmin(val reply: String) : ExecResult()
    object Unhandled : ExecResult()
}

class Executor(private val ctx: Context) {

    // ── Full app package map ───────────────────────────────────────────────
    private val apps = mapOf(
        "youtube" to "com.google.android.youtube",
        "youtube music" to "com.google.android.apps.youtube.music",
        "instagram" to "com.instagram.android",
        "whatsapp" to "com.whatsapp",
        "telegram" to "org.telegram.messenger",
        "facebook" to "com.facebook.katana",
        "twitter" to "com.twitter.android",
        "x" to "com.twitter.android",
        "snapchat" to "com.snapchat.android",
        "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "camera" to "com.android.camera2",
        "photos" to "com.google.android.apps.photos",
        "gallery" to "com.google.android.apps.photos",
        "settings" to "com.android.settings",
        "calculator" to "com.google.android.calculator",
        "calendar" to "com.google.android.calendar",
        "clock" to "com.google.android.deskclock",
        "play store" to "com.android.vending",
        "chrome" to "com.android.chrome",
        "files" to "com.google.android.documentsui",
        "linkedin" to "com.linkedin.android",
        "reddit" to "com.reddit.frontpage",
        "amazon" to "in.amazon.mShop.android.shopping",
        "flipkart" to "com.flipkart.android",
        "phonepe" to "com.phonepe.app",
        "google pay" to "com.google.android.apps.nbu.paisa.user",
        "gpay" to "com.google.android.apps.nbu.paisa.user",
        "paytm" to "net.one97.paytm",
        "uber" to "com.ubercab",
        "ola" to "com.olacabs.customer",
        "zomato" to "com.application.zomato",
        "swiggy" to "in.swiggy.android",
        "hotstar" to "in.startv.hotstar",
        "contacts" to "com.google.android.contacts",
        "messages" to "com.google.android.apps.messaging",
        "phone" to "com.google.android.dialer",
        "zoom" to "us.zoom.videomeetings",
        "meet" to "com.google.android.apps.tachyon",
        "teams" to "com.microsoft.teams",
        "discord" to "com.discord",
        "pinterest" to "com.pinterest",
        "tiktok" to "com.zhiliaoapp.musically",
        "prime video" to "com.amazon.avod.thirdpartyclient",
        "amazon prime" to "com.amazon.avod.thirdpartyclient",
        "google" to "com.google.android.googlequicksearchbox",
        "chrome" to "com.android.chrome",
    )

    fun run(r: NluResult): ExecResult = when (r.intent) {
        Intent.LOCK         -> lockScreen()
        Intent.OPEN_APP     -> openApp(r.entities["app"] ?: return ExecResult.Unhandled)
        Intent.SET_ALARM    -> setAlarm(
            r.entities["hour"]?.toIntOrNull() ?: return ExecResult.Unhandled,
            r.entities["minute"]?.toIntOrNull() ?: 0,
            r.entities["label"] ?: "")
        Intent.CANCEL_ALARM -> cancelAlarms()
        Intent.SHOW_ALARMS  -> showAlarms()
        Intent.CALL         -> makeCall(r.entities["contact"] ?: return ExecResult.Unhandled)
        Intent.SEND_SMS     -> sendSms(r.entities["contact"] ?: return ExecResult.Unhandled, r.entities["message"])
        Intent.SEARCH       -> webSearch(r.entities["query"] ?: return ExecResult.Unhandled)
        Intent.OPEN_URL     -> openUrl(r.entities["url"] ?: return ExecResult.Unhandled)
        Intent.WIFI_ON      -> wifi(true)
        Intent.WIFI_OFF     -> wifi(false)
        Intent.BT_ON        -> bluetooth(true)
        Intent.BT_OFF       -> bluetooth(false)
        Intent.TORCH_ON     -> torch(true)
        Intent.TORCH_OFF    -> torch(false)
        Intent.VOL_UP       -> volume(AudioManager.ADJUST_RAISE)
        Intent.VOL_DOWN     -> volume(AudioManager.ADJUST_LOWER)
        Intent.VOL_MUTE     -> mute()
        Intent.VOL_MAX      -> maxVol()
        Intent.PHOTO        -> photo()
        Intent.VIDEO        -> video()
        Intent.QUERY_TIME   -> time()
        Intent.QUERY_DATE   -> date()
        Intent.QUERY_BATTERY-> battery()
        Intent.TIMER        -> timer(r.entities["secs"]?.toIntOrNull() ?: return ExecResult.Unhandled)
        Intent.PLAY_MUSIC   -> music(r.entities["query"])
        Intent.STOP         -> ExecResult.Ok("__STOP__")
        Intent.UNKNOWN      -> ExecResult.Unhandled
    }

    // ── Lock ──────────────────────────────────────────────────────────────
    private fun lockScreen(): ExecResult {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn  = ComponentName(ctx, AdminReceiver::class.java)
        return if (dpm.isAdminActive(cn)) {
            dpm.lockNow()
            ExecResult.Ok("Locking your phone now!")
        } else {
            ExecResult.NeedAdmin("I need Device Admin permission to lock your screen. Enable it now?")
        }
    }

    // ── Open App ──────────────────────────────────────────────────────────
    fun openApp(name: String): ExecResult {
        val lo = name.lowercase()
        val pm = ctx.packageManager

        // 1. Exact map (longest key wins)
        val pkg = apps.entries.filter { lo.contains(it.key) }
            .maxByOrNull { it.key.length }?.value
        if (pkg != null) {
            pm.getLaunchIntentForPackage(pkg)?.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                ctx.startActivity(this)
                val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)) } catch (_: Exception) { name }
                return ExecResult.Ok("Opening $label!")
            }
        }

        // 2. Fuzzy search installed apps
        val all = pm.getInstalledApplications(0)
        val hit = all.minByOrNull { NLU.lev(lo, pm.getApplicationLabel(it).toString().lowercase()) }
        if (hit != null && NLU.lev(lo, pm.getApplicationLabel(hit).toString().lowercase()) <= 3) {
            pm.getLaunchIntentForPackage(hit.packageName)?.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                ctx.startActivity(this)
                return ExecResult.Ok("Opening ${pm.getApplicationLabel(hit)}!")
            }
        }

        return ExecResult.Ok("I couldn't find $name on your phone.")
    }

    // ── Alarm ─────────────────────────────────────────────────────────────
    private fun setAlarm(h: Int, m: Int, label: String): ExecResult {
        return try {
            ctx.startActivity(Intent(ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, h)
                putExtra(AlarmClock.EXTRA_MINUTES, m)
                putExtra(AlarmClock.EXTRA_MESSAGE, "SHREE Alarm")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
            ExecResult.Ok("Done! Alarm set for $label.")
        } catch (_: Exception) { ExecResult.Ok("Couldn't set alarm automatically. Try your Clock app.") }
    }

    private fun cancelAlarms() = try {
        ctx.startActivity(Intent(ACTION_SHOW_ALARMS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        ExecResult.Ok("Opening your alarms — toggle them off to cancel.")
    } catch (_: Exception) { ExecResult.Ok("Please open your Clock app to cancel alarms.") }

    private fun showAlarms() = try {
        ctx.startActivity(Intent(ACTION_SHOW_ALARMS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        ExecResult.Ok("Here are your alarms!")
    } catch (_: Exception) { ExecResult.Unhandled }

    // ── Call ──────────────────────────────────────────────────────────────
    private fun makeCall(contact: String): ExecResult {
        val digits = contact.replace(Regex("""[^0-9+]"""), "")
        val uri = if (digits.length >= 7) Uri.parse("tel:$digits")
                  else contactNumber(contact) ?: return ExecResult.Ok("I couldn't find $contact in your contacts.")
        return try {
            ctx.startActivity(Intent(Intent.ACTION_CALL, uri).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            ExecResult.Ok("Calling $contact!")
        } catch (_: SecurityException) {
            ExecResult.NeedPerm(android.Manifest.permission.CALL_PHONE, "I need call permission. Please grant it!")
        }
    }

    private fun contactNumber(name: String): Uri? = try {
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            val rows = buildList {
                while (cur.moveToNext()) add(
                    cur.getString(cur.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)) to
                    cur.getString(cur.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                )
            }
            val lo = name.lowercase()
            val match = rows.find { it.second.lowercase() == lo }
                ?: rows.find { it.second.lowercase().contains(lo) }
                ?: rows.minByOrNull { NLU.lev(lo, it.second.lowercase()) }
                    ?.takeIf { NLU.lev(lo, it.second.lowercase()) <= 3 }
            match?.let { Uri.parse("tel:${it.first}") }
        }
    } catch (_: Exception) { null }

    // ── SMS – FIXED: properly fills recipient ─────────────────────────────
    private fun sendSms(contact: String, body: String?): ExecResult {
        val digits = contact.replace(Regex("""[^0-9+]"""), "")
        val number = if (digits.length >= 7) digits
                     else contactNumber(contact)?.toString()?.removePrefix("tel:") ?: ""

        return try {
            ctx.startActivity(Intent(Intent.ACTION_SENDTO).apply {
                // smsto:<number> properly pre-fills the recipient field
                data = if (number.isNotBlank()) Uri.parse("smsto:$number") else Uri.parse("smsto:")
                if (!body.isNullOrBlank()) putExtra("sms_body", body)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
            val to = if (number.isNotBlank()) contact else "messaging app"
            ExecResult.Ok("Opening messages to $to${if (!body.isNullOrBlank()) " — message ready!" else "."}")
        } catch (_: Exception) { ExecResult.Ok("Couldn't open the messaging app.") }
    }

    // ── Web search ────────────────────────────────────────────────────────
    private fun webSearch(q: String): ExecResult {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(q)}"))
            .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return ExecResult.Ok("Searching for $q!")
    }

    // ── URL – FIXED triple-quoted regex ──────────────────────────────────
    private fun openUrl(raw: String): ExecResult {
        val url = if (raw.startsWith("http")) raw else "https://$raw"
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
            ExecResult.Ok("Opening $raw!")
        } catch (_: Exception) { ExecResult.Ok("Couldn't open that URL.") }
    }

    // ── WiFi ──────────────────────────────────────────────────────────────
    private fun wifi(on: Boolean): ExecResult {
        ctx.startActivity(Intent(Settings.Panel.ACTION_WIFI)
            .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return ExecResult.Ok(if (on) "Opening WiFi to turn it on!" else "Opening WiFi settings!")
    }

    // ── Bluetooth ─────────────────────────────────────────────────────────
    private fun bluetooth(on: Boolean): ExecResult {
        val action = if (on) BluetoothAdapter.ACTION_REQUEST_ENABLE else Settings.ACTION_BLUETOOTH_SETTINGS
        ctx.startActivity(Intent(action).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        return ExecResult.Ok(if (on) "Turning on Bluetooth!" else "Opening Bluetooth settings!")
    }

    // ── Flashlight ────────────────────────────────────────────────────────
    private fun torch(on: Boolean): ExecResult = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(cm.cameraIdList[0], on)
        ExecResult.Ok(if (on) "Flashlight on!" else "Flashlight off!")
    } catch (_: Exception) { ExecResult.Ok("Couldn't toggle flashlight.") }

    // ── Volume ────────────────────────────────────────────────────────────
    private fun volume(dir: Int): ExecResult {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return ExecResult.Ok(if (dir == AudioManager.ADJUST_RAISE) "Turning up the volume!" else "Turning it down!")
    }
    private fun mute(): ExecResult {
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
            .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        return ExecResult.Ok("Muted!")
    }
    private fun maxVol(): ExecResult {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
        return ExecResult.Ok("Volume maxed out!")
    }

    // ── Camera ────────────────────────────────────────────────────────────
    private fun photo() = try {
        ctx.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        ExecResult.Ok("Opening camera — say cheese!")
    } catch (_: Exception) { ExecResult.Ok("Couldn't open camera.") }

    private fun video() = try {
        ctx.startActivity(Intent(MediaStore.ACTION_VIDEO_CAPTURE).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        ExecResult.Ok("Recording video!")
    } catch (_: Exception) { ExecResult.Ok("Couldn't open camera.") }

    // ── Time / Date / Battery ─────────────────────────────────────────────
    private fun time(): ExecResult {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR).let { if (it == 0) 12 else it }
        val m = c.get(Calendar.MINUTE).toString().padStart(2,'0')
        val ampm = if (c.get(Calendar.AM_PM) == Calendar.AM) "AM" else "PM"
        return ExecResult.Ok("It's $h:$m $ampm.")
    }
    private fun date(): ExecResult {
        val c = Calendar.getInstance()
        val days = arrayOf("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
        val months = arrayOf("January","February","March","April","May","June","July","August","September","October","November","December")
        return ExecResult.Ok("Today is ${days[c.get(Calendar.DAY_OF_WEEK)-1]}, ${c.get(Calendar.DAY_OF_MONTH)} ${months[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)}.")
    }
    private fun battery(): ExecResult {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val chg = bm.isCharging
        val msg = when {
            lvl >= 80 -> "Battery is at $lvl percent${if (chg) " and charging" else ""}. Looking good!"
            lvl >= 30 -> "Battery is at $lvl percent${if (chg) " — charging" else ""}."
            else -> "Battery is low — only $lvl percent left! Please charge soon${if (chg) ", which you're already doing" else ""}."
        }
        return ExecResult.Ok(msg)
    }

    // ── Timer ─────────────────────────────────────────────────────────────
    private fun timer(secs: Int): ExecResult {
        val label = buildString {
            val h = secs / 3600; val m = (secs % 3600) / 60; val s = secs % 60
            if (h > 0) append("$h hour${if (h > 1) "s" else ""} ")
            if (m > 0) append("$m minute${if (m > 1) "s" else ""} ")
            if (s > 0) append("$s second${if (s > 1) "s" else ""}")
        }.trim()
        return try {
            ctx.startActivity(Intent(ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, secs)
                putExtra(AlarmClock.EXTRA_MESSAGE, "SHREE Timer")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
            ExecResult.Ok("Timer set for $label!")
        } catch (_: Exception) { ExecResult.Ok("Couldn't set the timer.") }
    }

    // ── Music ─────────────────────────────────────────────────────────────
    private fun music(query: String?): ExecResult {
        val intent = if (!query.isNullOrBlank())
            Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/${Uri.encode(query)}"))
                .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        else
            ctx.packageManager.getLaunchIntentForPackage("com.spotify.music")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com"))
                    .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
        ctx.startActivity(intent)
        return ExecResult.Ok(if (!query.isNullOrBlank()) "Playing $query on Spotify!" else "Opening Spotify!")
    }
}
