package com.shree.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.shree.ui.ShreeActivity
import com.shree.util.SecurePrefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Always-on background service that polls for "Hey SHREE".
 * Uses a rolling SpeechRecognizer loop (5-second windows).
 * When wake word detected → opens ShreeActivity + auto-starts listening.
 */
class WakeService : LifecycleService() {

    companion object {
        const val CH    = "shree_wake"
        const val NOTIF = 9
        val PHRASES = listOf(
            "hey shree","hi shree","ok shree","okay shree",
            "hello shree","shree","hey sree","hey sri","shri"
        )

        fun start(ctx: Context) = ctx.startForegroundService(Intent(ctx, WakeService::class.java))
        fun stop(ctx: Context)  = ctx.stopService(Intent(ctx, WakeService::class.java))
    }

    private var asr: SpeechRecognizer? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF, buildNotif())
        running = true
        loop()
    }

    override fun onDestroy() { running = false; asr?.destroy(); super.onDestroy() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return START_STICKY
    }

    private fun loop() = lifecycleScope.launch {
        while (isActive && running) {
            if (!SecurePrefs.wakeEnabled) { delay(3000); continue }
            if (!SpeechRecognizer.isRecognitionAvailable(this@WakeService)) { delay(5000); continue }
            listenOnce()
            delay(400) // brief gap between sessions
        }
    }

    private fun listenOnce() {
        try {
            asr?.destroy()
            asr = SpeechRecognizer.createSpeechRecognizer(this)
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300L)
            }
            asr?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(err: Int) {} // loop handles restart
                override fun onEvent(t: Int, p: Bundle?) {}

                override fun onPartialResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.joinToString(" ")?.lowercase() ?: return
                    if (PHRASES.any { t.contains(it) }) wake()
                }

                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.joinToString(" ")?.lowercase() ?: return
                    if (PHRASES.any { t.contains(it) }) wake()
                }
            })
            asr?.startListening(i)
        } catch (e: Exception) { Log.e("WakeService", "listen error", e) }
    }

    private fun wake() {
        Log.d("WakeService", "WAKE WORD DETECTED")
        asr?.cancel()
        startActivity(Intent(this, ShreeActivity::class.java).apply {
            action = "com.shree.WAKE"
            flags  = Intent.FLAG_ACTIVITY_NEW_TASK or
                     Intent.FLAG_ACTIVITY_SINGLE_TOP or
                     Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        })
    }

    private fun createChannel() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CH, "SHREE Wake Word", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Listening for Hey SHREE"
                setShowBadge(false)
            }
        )
    }

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, ShreeActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeService::class.java).apply { action = "STOP" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setContentTitle("SHREE — Listening")
            .setContentText("""Say "Hey SHREE" to activate""")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Turn off", stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}

// ── Device Admin (screen lock) ────────────────────────────────────────────────
class AdminReceiver : DeviceAdminReceiver() {
    override fun onEnabled(ctx: Context, intent: Intent) { SecurePrefs.adminActive = true }
    override fun onDisabled(ctx: Context, intent: Intent) { SecurePrefs.adminActive = false }
}

// ── Boot Receiver ─────────────────────────────────────────────────────────────
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            SecurePrefs.init(ctx)
            if (SecurePrefs.wakeEnabled) WakeService.start(ctx)
        }
    }
}
