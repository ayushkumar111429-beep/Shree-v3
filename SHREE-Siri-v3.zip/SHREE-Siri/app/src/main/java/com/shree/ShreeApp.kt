package com.shree

import android.app.Application
import com.shree.util.SecurePrefs

class ShreeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SecurePrefs.init(this)
    }
}
