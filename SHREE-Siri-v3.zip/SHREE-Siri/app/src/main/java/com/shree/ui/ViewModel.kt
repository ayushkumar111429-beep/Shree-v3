package com.shree.ui

import android.Manifest
import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shree.data.Msg
import com.shree.data.Repo
import com.shree.pipeline.Brain
import com.shree.pipeline.Event
import com.shree.pipeline.State
import com.shree.service.AdminReceiver
import com.shree.service.WakeService
import com.shree.util.SecurePrefs
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val msgs: List<Msg> = emptyList(),
    val brainState: State = State.IDLE,
    val partial: String = "",
    val showApiDlg: Boolean = false,
    val showSettingsDlg: Boolean = false,
    val showAdminDlg: Boolean = false,
    val apiKey: String = "",
    val wakeOn: Boolean = true,
    val autoListen: Boolean = true,
    val pitch: Float = 1.2f,
    val speed: Float = 0.9f,
    val permsNeeded: List<String> = emptyList()
)

class VM(app: Application) : AndroidViewModel(app) {

    val brain = Brain(app)
    private val repo = Repo.get(app)
    private val ctx  = app.applicationContext

    private val _ui = MutableStateFlow(UiState(
        apiKey = SecurePrefs.apiKey,
        wakeOn = SecurePrefs.wakeEnabled,
        autoListen = SecurePrefs.autoListen,
        pitch = SecurePrefs.pitch,
        speed = SecurePrefs.speed
    ))
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        // Pipe brain state → ui
        viewModelScope.launch { brain.state.collect { s -> _ui.update { it.copy(brainState = s) } } }
        viewModelScope.launch { brain.partial.collect { p -> _ui.update { it.copy(partial = p) } } }
        // Pipe events
        viewModelScope.launch {
            brain.events.collect { e ->
                when (e) {
                    is Event.NeedAdmin      -> _ui.update { it.copy(showAdminDlg = true) }
                    is Event.NeedPerm       -> _ui.update { it.copy(permsNeeded = it.permsNeeded + e.perm) }
                    is Event.BadApiKey      -> _ui.update { it.copy(showApiDlg = true) }
                    is Event.Reply, is Event.UserSaid, is Event.NoConnection, null -> {}
                }
            }
        }
        // Observe DB messages
        viewModelScope.launch { repo.flow.collect { msgs -> _ui.update { it.copy(msgs = msgs) } } }
        // Services
        startServices()
        viewModelScope.launch { repo.prune() }
        // Greet
        viewModelScope.launch {
            kotlinx.coroutines.delay(1100)
            val g = if (SecurePrefs.apiKey.isBlank())
                "Hi! I'm SHREE. Please tap Settings and enter your API key to get started!"
            else
                "Hi! I'm SHREE. Tap the orb or say Hey SHREE anytime to talk to me!"
            brain.speak(g)
        }
    }

    fun listen()      { ensurePerm(Manifest.permission.RECORD_AUDIO) { brain.startListening() } }
    fun stopListen()  = brain.stopListening()
    fun stopSpeak()   = brain.stopSpeaking()
    fun send(t: String) { viewModelScope.launch { brain.process(t) } }
    fun onWake()      { viewModelScope.launch { kotlinx.coroutines.delay(250); listen() } }

    fun saveApiKey(k: String) {
        SecurePrefs.apiKey = k.trim()
        _ui.update { it.copy(apiKey = k.trim(), showApiDlg = false) }
    }

    fun toggleWake(on: Boolean) {
        SecurePrefs.wakeEnabled = on
        _ui.update { it.copy(wakeOn = on) }
        if (on) WakeService.start(ctx) else WakeService.stop(ctx)
    }
    fun toggleAutoListen(on: Boolean) { SecurePrefs.autoListen = on; _ui.update { it.copy(autoListen = on) } }
    fun setPitch(v: Float)  { SecurePrefs.pitch = v; _ui.update { it.copy(pitch = v) }; brain.applyVoiceSettings() }
    fun setSpeed(v: Float)  { SecurePrefs.speed = v; _ui.update { it.copy(speed = v) }; brain.applyVoiceSettings() }

    fun showApiDlg()       = _ui.update { it.copy(showApiDlg = true) }
    fun dismissApiDlg()    = _ui.update { it.copy(showApiDlg = false) }
    fun showSettings()     = _ui.update { it.copy(showSettingsDlg = true) }
    fun dismissSettings()  = _ui.update { it.copy(showSettingsDlg = false) }
    fun dismissAdminDlg()  = _ui.update { it.copy(showAdminDlg = false) }
    fun clearPerms()       = _ui.update { it.copy(permsNeeded = emptyList()) }
    fun clearHistory()     = viewModelScope.launch { repo.clear() }

    fun requestAdmin() {
        val cn = ComponentName(ctx, AdminReceiver::class.java)
        ctx.startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Needed so SHREE can lock your screen when you ask.")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
        dismissAdminDlg()
    }

    private fun startServices() {
        if (SecurePrefs.wakeEnabled && hasPerm(Manifest.permission.RECORD_AUDIO))
            WakeService.start(ctx)
    }

    private fun hasPerm(p: String) =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePerm(p: String, then: () -> Unit) {
        if (hasPerm(p)) then()
        else _ui.update { it.copy(permsNeeded = it.permsNeeded + p) }
    }

    override fun onCleared() { brain.destroy(); super.onCleared() }
}
