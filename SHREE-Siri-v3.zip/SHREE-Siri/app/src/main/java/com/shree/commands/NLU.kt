package com.shree.commands

// ── Intent enum ────────────────────────────────────────────────────────────────
enum class Intent {
    LOCK, OPEN_APP, SET_ALARM, CANCEL_ALARM, SHOW_ALARMS,
    CALL, SEND_SMS, SEARCH, OPEN_URL,
    WIFI_ON, WIFI_OFF, BT_ON, BT_OFF,
    TORCH_ON, TORCH_OFF,
    VOL_UP, VOL_DOWN, VOL_MUTE, VOL_MAX,
    PHOTO, VIDEO,
    QUERY_TIME, QUERY_DATE, QUERY_BATTERY,
    TIMER, PLAY_MUSIC,
    STOP,  // stop TTS / cancel
    UNKNOWN
}

data class NluResult(
    val intent: Intent,
    val confidence: Float,
    val entities: Map<String, String>
)

// ── Classifier ─────────────────────────────────────────────────────────────────
object NLU {

    private data class Rule(
        val intent: Intent,
        val must: List<String>,       // at least one must match
        val boost: List<String> = emptyList(),  // extras boost score
        val block: List<String> = emptyList()   // any match blocks this rule
    )

    private val rules = listOf(
        Rule(Intent.LOCK,      must = listOf("lock"),                   block = listOf("unlock")),
        Rule(Intent.OPEN_APP,  must = listOf("open","launch","start","go to","show me")),
        Rule(Intent.SET_ALARM, must = listOf("alarm"),
            boost = listOf("am","pm","o'clock","morning","evening","night","set","wake"),
            block = listOf("cancel","delete","show","list")),
        Rule(Intent.CANCEL_ALARM, must = listOf("cancel","delete","remove","clear"),
            boost = listOf("alarm")),
        Rule(Intent.SHOW_ALARMS,  must = listOf("show","list","see","my alarms","alarms")),
        Rule(Intent.CALL,      must = listOf("call","ring","dial","phone")),
        Rule(Intent.SEND_SMS,  must = listOf("text","message","sms","send"),
            block = listOf("voice message")),
        Rule(Intent.SEARCH,    must = listOf("search","google","look up","find","look for")),
        Rule(Intent.OPEN_URL,  must = listOf(".com",".in",".org",".net","website","www","browser")),
        Rule(Intent.WIFI_ON,   must = listOf("wifi","wi-fi"), boost = listOf("on","enable","turn on")),
        Rule(Intent.WIFI_OFF,  must = listOf("wifi","wi-fi"), boost = listOf("off","disable","turn off")),
        Rule(Intent.BT_ON,     must = listOf("bluetooth"),   boost = listOf("on","enable")),
        Rule(Intent.BT_OFF,    must = listOf("bluetooth"),   boost = listOf("off","disable")),
        Rule(Intent.TORCH_ON,  must = listOf("torch","flashlight","flash"),
            boost = listOf("on","open","enable","turn on")),
        Rule(Intent.TORCH_OFF, must = listOf("torch","flashlight","flash"),
            boost = listOf("off","close","disable","turn off")),
        Rule(Intent.VOL_UP,    must = listOf("volume"), boost = listOf("up","increase","louder","raise")),
        Rule(Intent.VOL_DOWN,  must = listOf("volume"), boost = listOf("down","lower","quieter","reduce")),
        Rule(Intent.VOL_MUTE,  must = listOf("mute","silent","silence","quiet")),
        Rule(Intent.VOL_MAX,   must = listOf("volume"), boost = listOf("max","maximum","full","100")),
        Rule(Intent.PHOTO,     must = listOf("photo","picture","selfie","pic"),
            boost = listOf("take","click","capture","shoot")),
        Rule(Intent.VIDEO,     must = listOf("video","record")),
        Rule(Intent.QUERY_TIME, must = listOf("time","clock","hour"),
            block = listOf("set","alarm","timer")),
        Rule(Intent.QUERY_DATE, must = listOf("date","today","day","what day"),
            block = listOf("set","alarm")),
        Rule(Intent.QUERY_BATTERY, must = listOf("battery","charge","charging","power level")),
        Rule(Intent.TIMER,     must = listOf("timer","countdown"), block = listOf("alarm")),
        Rule(Intent.PLAY_MUSIC, must = listOf("play"), boost = listOf("music","song","spotify","on")),
        Rule(Intent.STOP,      must = listOf("stop","quiet","shut up","cancel","pause","nevermind")),
    )

    fun classify(input: String): NluResult {
        val lo = input.lowercase().trim()
        var bestIntent = Intent.UNKNOWN
        var bestScore = 0f

        for (rule in rules) {
            if (rule.block.any { lo.contains(it) } && rule.boost.isEmpty()) continue
            if (rule.block.any { lo.contains(it) } && !rule.boost.any { lo.contains(it) }) continue

            val mustHits = rule.must.count { lo.contains(it) }
            if (mustHits == 0) continue

            var score = mustHits.toFloat() / rule.must.size * 0.65f
            if (rule.boost.isNotEmpty()) {
                val boostHits = rule.boost.count { lo.contains(it) }
                score += boostHits.toFloat() / rule.boost.size * 0.35f
            } else {
                score += 0.2f
            }

            if (score > bestScore) {
                bestScore = score
                bestIntent = rule.intent
            }
        }

        return NluResult(
            intent = if (bestScore < 0.3f) Intent.UNKNOWN else bestIntent,
            confidence = bestScore.coerceIn(0f, 1f),
            entities = if (bestScore >= 0.3f) extract(bestIntent, lo, input) else emptyMap()
        )
    }

    // ── Entity extraction ──────────────────────────────────────────────────
    private fun extract(intent: Intent, lo: String, raw: String): Map<String, String> {
        val e = mutableMapOf<String, String>()
        when (intent) {
            Intent.OPEN_APP -> {
                afterKeyword(lo, listOf("open","launch","start","go to","show me"))
                    ?.let { e["app"] = it }
            }
            Intent.SET_ALARM -> {
                parseTime(lo)?.let { (h, m) ->
                    e["hour"] = h.toString()
                    e["minute"] = m.toString()
                    e["label"] = fmtTime(h, m)
                }
            }
            Intent.CALL -> {
                afterKeyword(lo, listOf("call","ring","dial","phone"))?.let { e["contact"] = it }
            }
            Intent.SEND_SMS -> {
                // "text/message <contact> saying/say/: <msg>"
                val patterns = listOf(
                    Regex("""(?:text|message|sms|send)\s+(?:a message to\s+|message\s+)?(.+?)\s+(?:saying|say|that|tells?|:)\s+(.+)"""),
                    Regex("""(?:send|message)\s+(.+?)\s+(?:saying|say|:)\s+(.+)""")
                )
                var matched = false
                for (p in patterns) {
                    val m = p.find(lo) ?: continue
                    e["contact"] = m.groupValues[1].trim()
                    e["message"] = m.groupValues[2].trim()
                    matched = true; break
                }
                if (!matched) afterKeyword(lo, listOf("text","message","sms"))?.let { e["contact"] = it }
            }
            Intent.SEARCH -> {
                afterKeyword(lo, listOf("search for","search","google","look up","find"))?.let { e["query"] = it }
            }
            Intent.OPEN_URL -> {
                // FIXED: use triple-quoted raw string — no escape confusion
                val urlRx = Regex("""(?:https?://)?(?:www\.)?([a-z0-9\-]+\.[a-z]{2,6})(/[^\s]*)?""")
                urlRx.find(lo)?.value?.let { e["url"] = it }
            }
            Intent.TIMER -> {
                parseDuration(lo)?.let { e["secs"] = it.toString() }
            }
            Intent.PLAY_MUSIC -> {
                afterKeyword(lo, listOf("play"))?.let { e["query"] = it }
            }
            else -> {}
        }
        return e
    }

    // ── Time parser ────────────────────────────────────────────────────────
    fun parseTime(text: String): Pair<Int, Int>? {
        // FIXED triple-quoted raw regex — no Kotlin escape issues
        val rx = Regex("""(\d{1,2})(?:[:\s](\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?""")
        val m = rx.find(text) ?: return null
        var h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: 0
        val mer = m.groupValues[3].replace(".", "").trim()
        when {
            mer == "pm" && h != 12 -> h += 12
            mer == "am" && h == 12 -> h = 0
            mer.isEmpty() && h in 1..6 && text.contains("alarm") -> h += 12
        }
        return if (h > 23 || min > 59) null else Pair(h, min)
    }

    fun parseDuration(text: String): Int? {
        var total = 0; var found = false
        Regex("""(\d+)\s*(?:hour|hr)s?""").find(text)?.let { total += it.groupValues[1].toInt() * 3600; found = true }
        Regex("""(\d+)\s*(?:minute|min)s?""").find(text)?.let { total += it.groupValues[1].toInt() * 60; found = true }
        Regex("""(\d+)\s*(?:second|sec)s?""").find(text)?.let { total += it.groupValues[1].toInt(); found = true }
        return if (found && total > 0) total else null
    }

    fun fmtTime(h: Int, m: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        val ampm = if (h < 12) "AM" else "PM"
        return "$h12:${m.toString().padStart(2,'0')} $ampm"
    }

    fun afterKeyword(text: String, kws: List<String>): String? {
        for (kw in kws.sortedByDescending { it.length }) {
            val i = text.indexOf(kw)
            if (i >= 0) {
                val after = text.substring(i + kw.length)
                    .trimStart()
                    .replace(Regex("""^(a|an|the|me|my|please|now)\s+"""), "")
                    .trim()
                if (after.isNotBlank()) return after
            }
        }
        return null
    }

    // ── Levenshtein for fuzzy app matching ─────────────────────────────────
    fun lev(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            dp[i][j] = if (a[i-1] == b[j-1]) dp[i-1][j-1]
                       else 1 + minOf(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
        return dp[a.length][b.length]
    }
}
