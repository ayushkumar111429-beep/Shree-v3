package com.shree.pipeline

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object API {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private const val URL = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-sonnet-4-20250514"

    private val SYSTEM = """
You are SHREE, a warm, sweet, brilliant female AI assistant — like Apple Siri but smarter and more personal.
Your replies are spoken aloud via Text-to-Speech, so follow these rules:
• NO markdown at all: no asterisks, no bullets, no hashtags, no numbered lists
• Keep replies SHORT — 1 to 3 natural sentences for most things
• Be warm, caring, occasionally witty — like a close best friend
• Use contractions naturally
• For current facts (news, sports, weather, prices) use the web_search tool
• Never say "based on my search" — just answer naturally
• Never mention being an AI or a language model
• Match the user's language
""".trimIndent()

    suspend fun chat(
        userMsg: String,
        history: List<Pair<String, String>>,
        apiKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val msgs = JSONArray()
            history.takeLast(16).forEach { (role, text) ->
                msgs.put(JSONObject().put("role", role).put("content", text))
            }
            msgs.put(JSONObject().put("role", "user").put("content", userMsg))

            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 800)
                .put("system", SYSTEM)
                .put("messages", msgs)
                .put("tools", JSONArray().put(
                    JSONObject().put("type", "web_search_20250305").put("name", "web_search")
                ))

            val req = Request.Builder()
                .url(URL)
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .build()

            val resp = http.newCall(req).execute()
            val raw  = resp.body?.string() ?: error("Empty response")
            val json = JSONObject(raw)

            if (!resp.isSuccessful) {
                val type = json.optJSONObject("error")?.optString("type") ?: ""
                throw Exception(when (type) {
                    "authentication_error" -> "__BAD_KEY__"
                    "rate_limit_error"     -> "__RATE__"
                    else -> json.optJSONObject("error")?.optString("message") ?: "API error"
                })
            }

            val content = json.optJSONArray("content") ?: error("No content")
            buildString {
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "text") append(b.optString("text"))
                }
            }.trim().ifBlank { error("Empty text") }
        }
    }
}
