package com.shree.pipeline

import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.shree.commands.Executor
import com.shree.commands.Intent
import com.shree.commands.NLU
import com.shree.data.Repo
import com.shree.util.SecurePrefs
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class State { IDLE, LISTENING, THINKING, SPEAKING }

sealed class Event {
    data class Reply(val text: String) : Event()
    data class UserSaid(val text: String) : Event()
    object NeedAdmin : Event()
    data class NeedPerm(val perm: String) : Event()
    object BadApiKey : Event()
    object NoConnection : Event()
}

class Brain(private val ctx: Context) {

    val state = MutableStateFlow(State.IDLE)
    val partial = MutableStateFlow("")
    val events = MutableStateFlow<Event?>(null)

    private val scope    = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val executor = Executor(ctx)
    private val repo     = Repo.get(ctx)
    private var tts: TextToSpeech? = null
    private var asr: SpeechRecognizer? = null
    private var ttsReady = false
    private var autoListenJob: Job? = null

    init { initTTS() }

    // ── TTS init ──────────────────────────────────────────────────────────
    private fun initTTS() {
        tts = TextToSpeech(ctx) { status ->
            if (status != TextToSpeech.SUCCESS) return@TextToSpeech
            // Best female-sounding locale
            for (loc in listOf(Locale("en","IN"), Locale.UK, Locale.US)) {
                if ((tts?.isLanguageAvailable(loc) ?: -1) >= TextToSpeech.LANG_AVAILABLE) {
                    tts?.language = loc; break
                }
            }
            applyVoiceSettings()
            ttsReady = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) { scope.launch { state.value = State.SPEAKING } }
                override fun onDone(id: String?) {
                    scope.launch {
                        state.value = State.IDLE
                        if (SecurePrefs.autoListen) {
                            autoListenJob = scope.launch { delay(350); startListening() }
                        }
                    }
                }
                override fun onError(id: String?) { scope.launch { state.value = State.IDLE } }
            })
        }
    }

    fun applyVoiceSettings() {
        tts?.setSpeechRate(SecurePrefs.speed)
        tts?.setPitch(SecurePrefs.pitch)
    }

    // ── Start Listening ────────────────────────────────────────────────────
    fun startListening() {
        if (state.value == State.LISTENING) return
        // Barge-in: interrupt TTS
        if (state.value == State.SPEAKING) { autoListenJob?.cancel(); tts?.stop() }

        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            emit(Event.Reply("Voice recognition isn't available. Please install the Google app."))
            return
        }

        asr?.destroy()
        asr = SpeechRecognizer.createSpeechRecognizer(ctx)

        val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 800L)
        }

        asr?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { state.value = State.LISTENING }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onPartialResults(bundle: Bundle?) {
                partial.value = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: ""
            }

            override fun onResults(bundle: Bundle?) {
                partial.value = ""
                val text = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull { it.isNotBlank() } ?: return
                scope.launch { process(text) }
            }

            override fun onError(err: Int) {
                partial.value = ""
                state.value = State.IDLE
                if (err == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                    scope.launch { delay(600); startListening() }
                }
            }

            override fun onEvent(type: Int, p: Bundle?) {}
        })

        asr?.startListening(intent)
    }

    fun stopListening() { asr?.stopListening(); partial.value = ""; state.value = State.IDLE }
    fun stopSpeaking() { autoListenJob?.cancel(); tts?.stop(); state.value = State.IDLE }

    // ── Process input ──────────────────────────────────────────────────────
    suspend fun process(text: String) = withContext(Dispatchers.Main) {
        if (text.isBlank() || state.value == State.THINKING) return@withContext
        asr?.cancel(); partial.value = ""
        state.value = State.THINKING
        scope.launch { repo.add("user", text) }
        emit(Event.UserSaid(text))

        // NLU
        val nlu = NLU.classify(text)
        Log.d("Brain", "intent=${nlu.intent} conf=${nlu.confidence} ents=${nlu.entities}")

        if (nlu.intent == Intent.STOP) { stopSpeaking(); state.value = State.IDLE; return@withContext }

        // Local command
        var reply: String? = null
        if (nlu.intent != Intent.UNKNOWN && nlu.confidence >= 0.38f) {
            when (val r = executor.run(nlu)) {
                is com.shree.commands.ExecResult.Ok -> {
                    if (r.reply == "__STOP__") { stopSpeaking(); state.value = State.IDLE; return@withContext }
                    reply = r.reply
                }
                is com.shree.commands.ExecResult.NeedAdmin -> { emit(Event.NeedAdmin); reply = r.reply }
                is com.shree.commands.ExecResult.NeedPerm  -> { emit(Event.NeedPerm(r.perm)); reply = r.reply }
                is com.shree.commands.ExecResult.Unhandled -> reply = null
            }
        }

        // AI fallback
        if (reply == null) reply = callAI(text)

        reply?.let {
            scope.launch { repo.add("assistant", it) }
            emit(Event.Reply(it))
            speak(it)
        }
    }

    private suspend fun callAI(text: String): String {
        val key = SecurePrefs.apiKey
        if (key.isBlank()) { emit(Event.BadApiKey); return "Please set your API key in Settings first!" }

        val history = repo.apiHistory(14)
        return when (val r = API.chat(text, history, key)) {
            else -> r.getOrElse { e ->
                when {
                    e.message?.contains("__BAD_KEY__") == true -> { emit(Event.BadApiKey); "Your API key seems invalid. Check it in Settings!" }
                    e.message?.contains("__RATE__") == true -> "I'm getting too many requests. Wait a moment and try again!"
                    e.message?.contains("Unable to resolve") == true ||
                    e.message?.contains("Failed to connect") == true -> { emit(Event.NoConnection); "I can't reach the internet right now." }
                    else -> "I had trouble with that. Could you try again?"
                }
            }
        }
    }

    // ── TTS speak ─────────────────────────────────────────────────────────
    fun speak(text: String) {
        if (!ttsReady || text.isBlank()) return
        val clean = text.replace(Regex("""[*_~`#>|\[\]\\]"""), "")
            .replace(Regex("""\n+"""), ". ").replace(Regex("""\s{2,}"""), " ").trim()
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "s${System.currentTimeMillis()}")
    }

    private fun emit(e: Event) { scope.launch { events.value = e } }

    fun destroy() { scope.cancel(); tts?.shutdown(); asr?.destroy() }
}
