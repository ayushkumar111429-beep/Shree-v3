package com.shree.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shree.pipeline.State
import com.shree.service.WakeService
import kotlin.math.*

class ShreeActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.RECORD_AUDIO] == true) WakeService.start(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ask only mic + notifications on launch
        val needed = listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) permLauncher.launch(needed.toTypedArray())

        setContent { ShreeScreen(onReqPerms = { permLauncher.launch(it.toTypedArray()) }) }
    }

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == "com.shree.WAKE") {
            // ViewModel handles auto-listen on wake
        }
    }
}

// ── Color palette ─────────────────────────────────────────────────────────────
private val BG      = Color(0xFF000000)
private val PINK    = Color(0xFFFF6EB4)
private val PURPLE  = Color(0xFFC070F0)
private val BLUE    = Color(0xFF50C8FF)
private val GOLD    = Color(0xFFFFD060)
private val GREEN   = Color(0xFF50F090)
private val SURFACE = Color(0x14FFFFFF)
private val BORDER  = Color(0x1AFFFFFF)
private val TEXT    = Color(0xFFF2EEFF)
private val TEXTSEC = Color(0xFFCCB8E8)
private val HINT    = Color(0x44D0B0F0)

@Composable
fun ShreeScreen(vm: VM = viewModel(), onReqPerms: (List<String>) -> Unit) {
    val ui     by vm.ui.collectAsStateWithLifecycle()
    val lState  = rememberLazyListState()
    var input   by remember { mutableStateOf("") }
    val haptic  = LocalHapticFeedback.current

    LaunchedEffect(ui.permsNeeded) {
        if (ui.permsNeeded.isNotEmpty()) { onReqPerms(ui.permsNeeded); vm.clearPerms() }
    }
    LaunchedEffect(ui.msgs.size) {
        if (ui.msgs.isNotEmpty()) lState.animateScrollToItem(ui.msgs.size - 1)
    }

    Box(Modifier.fillMaxSize().background(BG)) {
        // ── Dark blurred wallpaper effect ──────────────────────────────────
        DarkBlur()

        Column(Modifier.fillMaxSize()) {
            // ── Translucent status bar spacer ─────────────────────────────
            Spacer(Modifier.windowInsetsTopHeight(WindowInsets.statusBars))

            // ── Header ────────────────────────────────────────────────────
            TopBar(hasKey = ui.apiKey.isNotBlank(), onSettings = { vm.showSettings() }, onKey = { vm.showApiDlg() })

            // ── Conversation list ─────────────────────────────────────────
            LazyColumn(
                state = lState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(ui.msgs, key = { it.id }) { msg ->
                    AnimatedVisibility(true, enter = fadeIn() + slideInVertically { it / 3 }) {
                        Bubble(msg.role, msg.text)
                    }
                }
                if (ui.brainState == State.THINKING) {
                    item(key = "think") { ThinkDots() }
                }
            }

            // ── Siri waveform panel ───────────────────────────────────────
            SiriPanel(
                state = ui.brainState,
                partial = ui.partial,
                onTap = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    when (ui.brainState) {
                        State.LISTENING -> vm.stopListen()
                        State.SPEAKING  -> { vm.stopSpeak(); vm.listen() }
                        else            -> vm.listen()
                    }
                }
            )

            // ── Text input bar ────────────────────────────────────────────
            InputRow(
                text = input,
                onChange = { input = it },
                onSend = { if (input.isNotBlank()) { vm.send(input.trim()); input = "" } },
                onMic  = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    when (ui.brainState) {
                        State.LISTENING -> vm.stopListen()
                        State.SPEAKING  -> { vm.stopSpeak(); vm.listen() }
                        else            -> vm.listen()
                    }
                },
                listening = ui.brainState == State.LISTENING,
                busy = ui.brainState == State.THINKING
            )

            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }

        // ── Dialogs ───────────────────────────────────────────────────────
        if (ui.showApiDlg)      ApiKeyDlg(ui.apiKey, onSave = { vm.saveApiKey(it) }, onDismiss = { vm.dismissApiDlg() })
        if (ui.showSettingsDlg) SettingsDlg(ui, vm)
        if (ui.showAdminDlg)    AdminDlg(onEnable = { vm.requestAdmin() }, onDismiss = { vm.dismissAdminDlg() })
    }
}

// ── Dark blur background ──────────────────────────────────────────────────────
@Composable
fun DarkBlur() {
    val t = rememberInfiniteTransition("bg")
    val s by t.animateFloat(1f, 1.4f, infiniteRepeatable(tween(14000, easing = EaseInOutSine), RepeatMode.Reverse), "s")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Color(0xDD000000)) // base dark
        drawCircle(Brush.radialGradient(listOf(Color(0x12FF50AA), Color.Transparent),
            Offset(size.width*.3f, size.height*.2f), size.minDimension*.8f*s),
            center = Offset(size.width*.3f, size.height*.2f), radius = size.minDimension*.8f*s)
        drawCircle(Brush.radialGradient(listOf(Color(0x0E8C3CFF), Color.Transparent),
            Offset(size.width*.75f, size.height*.55f), size.minDimension*.6f*(2.2f-s)),
            center = Offset(size.width*.75f, size.height*.55f), radius = size.minDimension*.6f*(2.2f-s))
    }
}

// ── Top bar ───────────────────────────────────────────────────────────────────
@Composable
fun TopBar(hasKey: Boolean, onSettings: () -> Unit, onKey: () -> Unit) {
    val t = rememberInfiniteTransition("title")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(4500), RepeatMode.Reverse), "a")
    val tc = lerp(Color(0xFFFFC8E0), Color(0xFFD0A8FF), a)

    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Column {
            Text("SHREE", fontSize = 24.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp, color = tc)
            Text("YOUR PERSONAL AI ASSISTANT", fontSize = 8.5.sp, letterSpacing = 2.sp,
                color = Color.White.copy(.25f), fontWeight = FontWeight.Light)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (!hasKey) IconButton(onKey) {
                Icon(Icons.Default.VpnKey, null, tint = GOLD.copy(.8f), modifier = Modifier.size(21.dp))
            }
            IconButton(onSettings) {
                Icon(Icons.Default.Settings, null, tint = PINK.copy(.6f), modifier = Modifier.size(21.dp))
            }
        }
    }
}

// ── Siri-style waveform panel ─────────────────────────────────────────────────
@Composable
fun SiriPanel(state: State, partial: String, onTap: () -> Unit) {
    val inf = rememberInfiniteTransition("siri")

    // Waveform bars animation
    val bars = 28
    val amplitudes = (0 until bars).map { i ->
        val phase = i * 0.4f
        val speed = 350 + i * 18
        val amp by inf.animateFloat(0.15f, 1f,
            infiniteRepeatable(tween(speed, (i * 40) % 300, EaseInOutSine), RepeatMode.Reverse), "b$i")
        amp
    }

    // Glow pulse
    val glow by inf.animateFloat(0.4f, 1f,
        infiniteRepeatable(tween(1800, easing = EaseInOutSine), RepeatMode.Reverse), "g")

    // Ring pulse (listening)
    val ring by inf.animateFloat(1f, 1.08f,
        infiniteRepeatable(tween(900, easing = EaseInOutSine), RepeatMode.Reverse), "r")

    val activeColor = when (state) {
        State.LISTENING -> BLUE
        State.SPEAKING  -> PINK
        State.THINKING  -> GOLD
        else            -> PURPLE.copy(.6f)
    }
    val isActive = state != State.IDLE

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x22000000))
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {

            // Waveform + center orb
            Box(contentAlignment = Alignment.Center) {
                // Waveform bars behind orb
                if (isActive) {
                    Canvas(Modifier.width(280.dp).height(60.dp)) {
                        val barW = size.width / (bars * 2f)
                        val cx = size.width / 2f
                        for (i in 0 until bars) {
                            val x = i * (size.width / bars.toFloat()) + barW / 2
                            val h = size.height * amplitudes[i] * if (isActive) 0.85f else 0.2f
                            val distFromCenter = abs(x - cx) / cx
                            val alpha = (1f - distFromCenter * 0.7f).coerceIn(0.1f, 1f)
                            val barColor = lerp(activeColor, activeColor.copy(alpha = 0f), distFromCenter * 0.6f)
                            drawRoundRect(
                                color = barColor.copy(alpha = alpha * glow),
                                topLeft = Offset(x - barW / 2, (size.height - h) / 2),
                                size = Size(barW - 1f, h),
                                cornerRadius = CornerRadius(barW / 2)
                            )
                        }
                    }
                }

                // Center orb (tap target)
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .scale(if (state == State.LISTENING) ring else 1f)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                when (state) {
                                    State.LISTENING -> listOf(Color(0xFFC0F0FF), Color(0xFF50B8FF), BLUE.copy(.7f))
                                    State.SPEAKING  -> listOf(Color(0xFFFFD0E8), PINK, PURPLE)
                                    State.THINKING  -> listOf(Color(0xFFFFF0C0), GOLD, Color(0xFFFF9040))
                                    else            -> listOf(Color(0xFFE8D0FF), PURPLE, Color(0xFF6030C0))
                                }
                            )
                        )
                        .shadow(if (isActive) 24.dp else 8.dp, CircleShape,
                            ambientColor = activeColor, spotColor = activeColor)
                        .clickable(onClick = onTap),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawCircle(Brush.radialGradient(
                            listOf(Color.White.copy(.4f), Color.Transparent),
                            Offset(size.width*.32f, size.height*.28f), size.minDimension*.42f))
                    }
                    Text(when (state) {
                        State.LISTENING -> "👂"; State.SPEAKING -> "💬"; State.THINKING -> "✨"; else -> "🌸"
                    }, fontSize = 28.sp)
                }
            }

            // Status line
            val stateLabel = when (state) {
                State.IDLE      -> "Tap orb  •  Say \"Hey SHREE\""
                State.LISTENING -> "Listening…"
                State.THINKING  -> "Thinking…"
                State.SPEAKING  -> "Speaking  —  tap to interrupt"
            }
            val fadeA by inf.animateFloat(.5f, 1f,
                infiniteRepeatable(tween(1000, easing = EaseInOutSine), RepeatMode.Reverse), "fa")

            Text(stateLabel, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Medium,
                color = if (state == State.IDLE) Color.White.copy(.25f)
                        else activeColor.copy(alpha = fadeA))

            // Partial transcript
            AnimatedVisibility(partial.isNotBlank(), enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                Text("\"$partial\"", fontSize = 13.sp, color = BLUE.copy(.8f),
                    fontStyle = FontStyle.Italic, modifier = Modifier.padding(horizontal = 28.dp),
                    textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// ── Chat bubbles ──────────────────────────────────────────────────────────────
@Composable
fun Bubble(role: String, text: String) {
    val isUser = role == "user"
    Row(Modifier.fillMaxWidth(), if (isUser) Arrangement.End else Arrangement.Start, Alignment.Bottom) {
        if (!isUser) {
            Box(Modifier.size(28.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFFFFB8D8), PURPLE))),
                Alignment.Center) { Text("🌸", fontSize = 14.sp) }
            Spacer(Modifier.width(6.dp))
        }
        Box(
            Modifier.widthIn(max = 280.dp)
                .clip(RoundedCornerShape(18.dp, 18.dp, if (isUser) 5.dp else 18.dp, if (isUser) 18.dp else 5.dp))
                .background(if (isUser) Brush.linearGradient(listOf(Color(0x30FF6EB4), Color(0x30A046FF)))
                    else Brush.linearGradient(listOf(SURFACE, SURFACE)))
                .border(1.dp, if (isUser) PINK.copy(.35f) else BORDER,
                    RoundedCornerShape(18.dp, 18.dp, if (isUser) 5.dp else 18.dp, if (isUser) 18.dp else 5.dp))
                .padding(13.dp, 9.dp)
        ) {
            Text(text, fontSize = 14.sp, lineHeight = 21.sp,
                color = if (isUser) Color(0xFFFFDAEE) else TEXT)
        }
    }
}

@Composable
fun ThinkDots() {
    val t = rememberInfiniteTransition("dots")
    Row(verticalAlignment = Alignment.Bottom) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFFFB8D8), PURPLE))),
            Alignment.Center) { Text("🌸", fontSize = 14.sp) }
        Spacer(Modifier.width(6.dp))
        Box(Modifier.clip(RoundedCornerShape(18.dp, 18.dp, 18.dp, 5.dp))
            .background(SURFACE).border(1.dp, BORDER, RoundedCornerShape(18.dp, 18.dp, 18.dp, 5.dp))
            .padding(16.dp, 12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(3) { i ->
                    val s by t.animateFloat(0f, 1f,
                        infiniteRepeatable(tween(550, i * 185, EaseInOutSine), RepeatMode.Reverse), "d$i")
                    Box(Modifier.size(7.dp).scale(s).clip(CircleShape).background(PINK))
                }
            }
        }
    }
}

// ── Input row ─────────────────────────────────────────────────────────────────
@Composable
fun InputRow(text: String, onChange: (String) -> Unit, onSend: () -> Unit,
             onMic: () -> Unit, listening: Boolean, busy: Boolean) {
    Surface(Modifier.fillMaxWidth(), color = Color(0xEE000000)) {
        Row(Modifier.fillMaxWidth().padding(10.dp, 6.dp).imePadding(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(
                value = text, onValueChange = onChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type a message…", color = HINT, fontSize = 14.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PINK.copy(.45f), unfocusedBorderColor = PINK.copy(.12f),
                    focusedTextColor = TEXT, unfocusedTextColor = TEXT,
                    cursorColor = PINK, focusedContainerColor = SURFACE, unfocusedContainerColor = SURFACE
                ),
                shape = RoundedCornerShape(22.dp), textStyle = TextStyle(fontSize = 14.sp)
            )
            val ok = text.isNotBlank() && !busy
            Box(Modifier.size(42.dp).clip(CircleShape)
                .background(if (ok) Brush.linearGradient(listOf(PINK, PURPLE))
                    else Brush.linearGradient(listOf(Color.White.copy(.06f), Color.White.copy(.06f))))
                .clickable(enabled = ok, onClick = onSend), Alignment.Center) {
                Icon(Icons.Default.Send, null,
                    tint = if (ok) Color.White else Color.White.copy(.2f), modifier = Modifier.size(18.dp))
            }
            Box(Modifier.size(46.dp).clip(CircleShape)
                .background(Brush.linearGradient(if (listening) listOf(BLUE, Color(0xFF3060E0)) else listOf(PINK, PURPLE)))
                .shadow(10.dp, CircleShape, ambientColor = if (listening) BLUE else PINK, spotColor = if (listening) BLUE else PINK)
                .clickable(onClick = onMic), Alignment.Center) {
                Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, null,
                    tint = Color.White, modifier = Modifier.size(22.dp))
            }
        }
    }
}

// ── Dialogs ───────────────────────────────────────────────────────────────────
@Composable
fun ApiKeyDlg(current: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var v by remember { mutableStateOf(current) }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("🔑  API Key", color = TEXT, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Enter your Anthropic API key.\nGet one free at console.anthropic.com",
                    color = TEXTSEC, fontSize = 13.sp, lineHeight = 18.sp)
                OutlinedTextField(v, { v = it },
                    placeholder = { Text("sk-ant-api…", color = HINT) }, singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PINK, unfocusedBorderColor = PINK.copy(.2f),
                        focusedTextColor = TEXT, unfocusedTextColor = TEXT,
                        cursorColor = PINK, focusedContainerColor = SURFACE, unfocusedContainerColor = SURFACE
                    ), shape = RoundedCornerShape(12.dp))
            }
        },
        confirmButton = {
            Button({ if (v.isNotBlank()) onSave(v.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = PINK),
                shape = RoundedCornerShape(12.dp)) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = TEXTSEC) } },
        containerColor = Color(0xFF150D28), shape = RoundedCornerShape(20.dp))
}

@Composable
fun SettingsDlg(ui: UiState, vm: VM) {
    var confirmClear by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = { vm.dismissSettings() },
        title = { Text("⚙️  Settings", color = TEXT, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton({ vm.dismissSettings(); vm.showApiDlg() }, Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, PINK.copy(.35f)), shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PINK)) {
                    Icon(Icons.Default.VpnKey, null, Modifier.size(15.dp)); Spacer(Modifier.width(8.dp))
                    Text(if (ui.apiKey.isNotBlank()) "Update API Key" else "Set API Key")
                }
                HorizontalDivider(color = BORDER)
                SRow("Hey SHREE wake word", ui.wakeOn, { vm.toggleWake(it) })
                SRow("Auto-listen after reply", ui.autoListen, { vm.toggleAutoListen(it) })
                HorizontalDivider(color = BORDER)
                Text("Voice pitch  (${String.format("%.1f", ui.pitch)})", fontSize = 12.sp, color = TEXTSEC)
                Slider(ui.pitch, { vm.setPitch(it) }, valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = PINK, activeTrackColor = PINK))
                Text("Voice speed  (${String.format("%.1f", ui.speed)})", fontSize = 12.sp, color = TEXTSEC)
                Slider(ui.speed, { vm.setSpeed(it) }, valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = PURPLE, activeTrackColor = PURPLE))
                HorizontalDivider(color = BORDER)
                if (confirmClear) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ confirmClear = false }, Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TEXTSEC)) { Text("Cancel") }
                    Button({ vm.clearHistory(); confirmClear = false }, Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD03060))) { Text("Erase") }
                } else OutlinedButton({ confirmClear = true }, Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, Color(0xFFD03060).copy(.35f)), shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD03060))) {
                    Icon(Icons.Default.DeleteForever, null, Modifier.size(15.dp)); Spacer(Modifier.width(8.dp))
                    Text("Clear history")
                }
            }
        },
        confirmButton = { TextButton({ vm.dismissSettings() }) { Text("Done", color = PINK, fontWeight = FontWeight.Bold) } },
        containerColor = Color(0xFF150D28), shape = RoundedCornerShape(20.dp))
}

@Composable
fun SRow(label: String, on: Boolean, toggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = TEXT, modifier = Modifier.weight(1f))
        Switch(on, toggle, colors = SwitchDefaults.colors(checkedThumbColor = Color.White,
            checkedTrackColor = PINK, uncheckedTrackColor = SURFACE))
    }
}

@Composable
fun AdminDlg(onEnable: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("🔒  Screen Lock", color = TEXT, fontWeight = FontWeight.Bold) },
        text = { Text("Enable Device Admin so SHREE can lock your screen when you say \"Lock my phone\".\n\nSHREE only uses this for screen lock — nothing else.",
            color = TEXTSEC, fontSize = 13.sp, lineHeight = 19.sp) },
        confirmButton = { Button(onEnable, colors = ButtonDefaults.buttonColors(containerColor = PINK),
            shape = RoundedCornerShape(12.dp)) { Text("Enable") } },
        dismissButton = { TextButton(onDismiss) { Text("Not now", color = TEXTSEC) } },
        containerColor = Color(0xFF150D28), shape = RoundedCornerShape(20.dp))
}
