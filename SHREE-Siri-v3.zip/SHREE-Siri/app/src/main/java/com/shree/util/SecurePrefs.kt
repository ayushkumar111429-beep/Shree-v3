package com.shree.util

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object SecurePrefs {

    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = try {
            val mk = MasterKey.Builder(ctx)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                ctx, "shree_secure",
                mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            // Emulator fallback
            ctx.getSharedPreferences("shree_plain", Context.MODE_PRIVATE)
        }
    }

    private fun p() = checkNotNull(prefs) { "Call SecurePrefs.init(context) first" }

    var apiKey: String
        get() = p().getString("api_key", "") ?: ""
        set(v) { p().edit().putString("api_key", v).apply() }

    var wakeEnabled: Boolean
        get() = p().getBoolean("wake_on", true)
        set(v) { p().edit().putBoolean("wake_on", v).apply() }

    var autoListen: Boolean
        get() = p().getBoolean("auto_listen", true)
        set(v) { p().edit().putBoolean("auto_listen", v).apply() }

    var pitch: Float
        get() = p().getFloat("pitch", 1.2f)
        set(v) { p().edit().putFloat("pitch", v).apply() }

    var speed: Float
        get() = p().getFloat("speed", 0.9f)
        set(v) { p().edit().putFloat("speed", v).apply() }

    var adminActive: Boolean
        get() = p().getBoolean("admin", false)
        set(v) { p().edit().putBoolean("admin", v).apply() }
}
