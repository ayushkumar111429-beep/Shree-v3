# 🌸 SHREE — Apple Siri for Android

SHREE is a pixel-perfect Siri-style voice assistant for Android built with Kotlin + Jetpack Compose.

---

## ✅ What SHREE Does (Siri-level features)

| Feature | How |
|---|---|
| **"Hey SHREE"** wake word | Always-on background service |
| **Screen lock** | Device Admin API — real lock |
| **Open any app** | Package manager + fuzzy matching |
| **Set / cancel alarms** | AlarmClock API (silent, no popup) |
| **Make calls** | ACTION_CALL — dials directly |
| **Send SMS** | Fills contact AND message body |
| **Web search** | Opens Google with query |
| **WiFi / Bluetooth** | Settings panel |
| **Flashlight** | Camera2 torch mode |
| **Volume control** | AudioManager |
| **Take photo / video** | Camera intent |
| **Time / Date / Battery** | System services |
| **Set timers** | AlarmClock timer API |
| **Play music** | Spotify search |
| **Any question** | Claude AI + live web search |
| **Persistent memory** | Room database (7 days) |
| **Encrypted API key** | AES-256 EncryptedSharedPreferences |
| **Auto-listen after reply** | Siri-style conversation loop |
| **Barge-in (interrupt)** | Tap orb while speaking |
| **Translucent overlay UI** | Like real Siri |
| **Animated waveform** | Siri-style color bars |
| **Restarts after reboot** | BootReceiver |

---

## 📋 What You Need

1. **Android Studio** (free) — https://developer.android.com/studio
2. **An Android phone** (Android 10 or higher)
3. **A USB cable**
4. **Anthropic API key** (free tier at https://console.anthropic.com)

---

## 🚀 Step-by-Step Setup

### Step 1 — Install Android Studio
- Go to https://developer.android.com/studio
- Download and install (choose "Standard" setup when asked)
- Let it install the Android SDK — takes ~5 minutes

### Step 2 — Open SHREE in Android Studio
1. Launch Android Studio
2. On the welcome screen, click **Open**
3. Navigate to the **SHREE-Siri** folder and click OK
4. Wait for "Gradle sync" to complete — bottom bar shows progress
5. If it says "Install SDK" — click Install and accept license

### Step 3 — Enable Developer Mode on your phone
1. Open **Settings → About Phone**
2. Find **Build Number** — tap it **7 times fast**
3. You'll see "You are now a developer!"
4. Go back → **Settings → Developer Options**
5. Turn on **USB Debugging**

### Step 4 — Connect your phone
1. Plug in via USB cable
2. On your phone, tap **Allow USB Debugging**
3. In Android Studio, your phone appears in the toolbar dropdown (e.g. "Pixel 7")

### Step 5 — Build and install
1. In the toolbar, make sure your phone is selected (not an emulator)
2. Click the **green ▶ Run button** (or press Shift+F10)
3. Android Studio builds and installs SHREE on your phone (~60 seconds)
4. SHREE launches automatically!

### Step 6 — Set your API key
1. Open SHREE
2. Tap the **⚙️ gear icon** (top right)
3. Tap **Set API Key**
4. Paste your key from https://console.anthropic.com
5. Tap **Save** — SHREE is now fully powered!

### Step 7 — Enable screen lock (optional)
1. Say **"Lock my phone"** or tap the orb and say it
2. A dialog appears asking for Device Admin permission
3. Tap **Activate** — now SHREE can lock your screen!

---

## 🎤 How to Use SHREE

**Voice:** Say **"Hey SHREE"** from anywhere — SHREE activates and listens
**Tap:**   Tap the glowing orb in the center of the panel
**Type:**  Use the text input at the bottom
**Interrupt:** Tap the orb while SHREE is speaking to stop and respond

### Example commands:
```
"Hey SHREE"
"Lock my phone"
"Open WhatsApp"
"Set alarm for 7 AM"
"Call Mom"
"Text Priya saying I'll be late"
"Turn on flashlight"
"What's the weather today?"
"Volume up"
"Set a 10 minute timer"
"Search for best restaurants near me"
"What's my battery level?"
"Play Bollywood hits on Spotify"
```

---

## 🔐 Permissions (what SHREE asks for and why)

SHREE asks only when needed:
- **Microphone** — to hear your voice (asked at startup)
- **Notifications** — for the background service (asked at startup)
- **Phone** — to make calls (asked when you say "call")
- **Contacts** — to find contacts by name (asked when you say "call" or "text")
- **Camera** — for flashlight and photos (asked when needed)
- **Device Admin** — for screen lock only (asked when you say "lock my phone")

---

## ⚙️ Settings (tap the gear icon)

- **Hey SHREE** — toggle always-on wake word on/off
- **Auto-listen after reply** — Siri-style: SHREE keeps listening for follow-up
- **Voice pitch** — make SHREE's voice higher or lower
- **Voice speed** — make SHREE speak faster or slower
- **Clear history** — erase all conversation history

---

## 🔧 Troubleshooting

| Problem | Fix |
|---|---|
| Gradle sync fails | File → Sync Project with Gradle Files |
| Phone not detected | Unplug, re-plug USB; check "Allow USB debugging" |
| SHREE doesn't speak | Make sure your volume is on |
| "Recognition not available" | Update the Google app on your phone |
| Wake word not working | Grant microphone permission; check Hey SHREE is ON in Settings |
| Lock screen doesn't work | Say "lock my phone" → tap Activate in the dialog |
| SHREE says "Please set API key" | Tap ⚙️ → Set API Key → paste your key |

---

## 🏗 Project Structure

```
SHREE-Siri/
├── app/src/main/
│   ├── java/com/shree/
│   │   ├── ShreeApp.kt              ← Application class
│   │   ├── ui/
│   │   │   ├── ShreeActivity.kt     ← Full Siri-style Compose UI
│   │   │   └── ViewModel.kt         ← State management
│   │   ├── pipeline/
│   │   │   ├── Brain.kt             ← Voice pipeline state machine
│   │   │   └── API.kt               ← Anthropic API client
│   │   ├── commands/
│   │   │   ├── NLU.kt               ← Intent classifier + entity extractor
│   │   │   └── Executor.kt          ← All phone commands
│   │   ├── service/
│   │   │   └── WakeService.kt       ← Hey SHREE background service
│   │   ├── data/
│   │   │   └── Repo.kt              ← Room DB + conversation repo
│   │   └── util/
│   │       └── SecurePrefs.kt       ← AES-256 encrypted storage
│   ├── res/
│   │   ├── xml/device_admin.xml     ← Screen lock policy
│   │   └── values/styles.xml        ← Translucent overlay theme
│   └── AndroidManifest.xml
└── README.md
```

---

*SHREE is powered by Claude AI (Anthropic) • Built with Kotlin + Jetpack Compose*
